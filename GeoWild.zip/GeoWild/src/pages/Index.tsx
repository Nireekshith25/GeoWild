import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import PhotoGallery from '@/components/PhotoGallery';

const Index = () => {
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);

  const features = [
    {
      title: "Safari Adventures",
      description: "Immerse yourself in the natural habitat of majestic animals and witness their beauty up close.",
      color: "bg-wildlife-sand",
      borderColor: "border-wildlife-sand",
      hoverColor: "hover:border-wildlife-sand/70"
    },
    {
      title: "Forest Exploration",
      description: "Trek through dense, vibrant forests teeming with diverse plant and animal species.",
      color: "bg-wildlife-leaf",
      borderColor: "border-wildlife-leaf",
      hoverColor: "hover:border-wildlife-leaf/70"
    },
    {
      title: "Ocean Discovery",
      description: "Dive into the mysterious underwater world and encounter fascinating marine creatures.",
      color: "bg-wildlife-water",
      borderColor: "border-wildlife-water",
      hoverColor: "hover:border-wildlife-water/70"
    }
  ];

  return (
    <div className="min-h-screen w-full">
      {/* Hero Section with Wildlife Theme */}
      <section className="h-screen flex items-center justify-center bg-wildlife-gradient bg-forest-texture px-4 relative">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto text-center max-w-3xl relative z-10">
          <h1 className="text-4xl md:text-6xl font-safari font-bold mb-6 text-white text-shadow-wildlife animate-wildlife-fade">
            Explore The <span className="text-wildlife-sunset">Wild</span> World
          </h1>
          <p className="text-lg md:text-xl text-wildlife-sand mb-8 font-nature animate-wildlife-fade" style={{ animationDelay: '0.2s' }}>
            Embark on an adventure through nature's most breathtaking landscapes and discover the beauty of wildlife
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-wildlife-fade" style={{ animationDelay: '0.4s' }}>
            <Button 
              variant="wildlife" 
              size="xl" 
              className="font-safari tracking-wide group"
            >
              <span className="relative z-10 transition-transform group-hover:scale-105">Begin Your Journey</span>
            </Button>
            <Button 
              variant="outline" 
              size="xl"
              className="border-wildlife-sand text-wildlife-sand hover:bg-wildlife-forest/30 font-safari tracking-wide group"
            >
              <span className="relative z-10 transition-transform group-hover:scale-105">Discover Tours</span>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section with Wildlife Theme */}
      <section className="py-20 px-4 bg-white bg-forest-texture">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-safari font-bold text-center mb-12 text-wildlife-forest text-shadow-nature">
            Experience Wildlife
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <div 
                key={i} 
                className={`${feature.color}/10 p-8 rounded-lg border ${feature.borderColor}/20 ${feature.hoverColor} transition-all duration-500 hover:shadow-lg hover:translate-y-[-8px]`}
                onMouseEnter={() => setHoveredFeature(i)}
                onMouseLeave={() => setHoveredFeature(null)}
              >
                <h3 className={`text-xl font-safari font-semibold mb-4 text-wildlife-forest transition-all duration-300 ${hoveredFeature === i ? 'text-wildlife-sunset scale-105' : ''}`}>
                  {feature.title}
                </h3>
                <p className="text-wildlife-earth font-nature">
                  {feature.description}
                </p>
                <Button 
                  variant="ghost" 
                  className={`mt-6 text-wildlife-forest hover:text-wildlife-sunset px-0 transition-all duration-300 ${hoveredFeature === i ? 'translate-x-2' : ''}`}
                >
                  Learn more →
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Photo Gallery Section */}
      <PhotoGallery />

      {/* CTA Section */}
      <section className="py-20 px-4 bg-sunset-gradient text-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl font-safari font-bold mb-6 text-shadow-wildlife">Ready to explore the wild?</h2>
          <p className="text-wildlife-sand mb-8 font-nature">Join thousands of adventurers who have already experienced our guided wildlife tours</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              variant="forest" 
              size="xl" 
              className="font-safari tracking-wide group"
            >
              <span className="relative z-10 transition-transform group-hover:scale-105">Book Your Adventure</span>
            </Button>
            <Button 
              variant="savanna" 
              size="xl" 
              className="font-safari tracking-wide group"
            >
              <span className="relative z-10 transition-transform group-hover:scale-105">View Gallery</span>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
